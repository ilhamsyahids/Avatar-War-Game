# Tubes Algoritma Stuktur Data

## How To Run
1. Copy all headers file to folder (e.g. headers).
2. Copy all C code file to another folder (e.g. src).
3. In the outsite folders copy main.c
4. Run:

```gcc -Iheaders main.c src/fileloader.c src/gamemap.c src/buildingrelationgraph.c src/mesinkar.c src/mesinkata.c src/mapmatrix.c src/buildingarray.c src/building.c src/point.c src/buildinglist.c src/player.c src/skillqueue.c src/skill.c src/pcolor.c src/actionstackt.c src/commands.c -o output.exe```
